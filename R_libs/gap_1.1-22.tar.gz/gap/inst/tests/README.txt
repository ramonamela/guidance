This directory contains information on experimental work.

C/		C program
R/		R codes
comp.score/	Example for comp.score
kinship/	Work related to kinship modeling
ms/		ms source code associated with read.ms.output
twinan90/	Deprecated twinan90 files
xls/		Original BFDP and FPRP function

README.txt	This file
