# 4-12-2013 MRC-Epid JHZ

# note the ped51 object can be established via code after l51
