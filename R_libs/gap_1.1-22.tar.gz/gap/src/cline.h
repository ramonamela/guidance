int get_flag(int, char**, char*, int, void*);
int get_arg(int, char**, char*);
char *unrec(int, char**);
